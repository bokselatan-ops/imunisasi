# imunisasi-app (template)

Template ini berisi frontend (React) + backend (Express) yang terhubung ke Supabase (Postgres).
Kamu bisa upload folder `backend` dan `frontend` langsung ke GitHub repository lalu deploy.

## Link Google Sheets (dari kamu)
https://docs.google.com/spreadsheets/d/171PvbAWpI4QR2xojnxdLiofjan9cZ9mzJJJB1FLd3y0/edit?gid=0#gid=0

## Cara pakai singkat
1. Buat project Supabase, catat `Project URL` dan `Anon Key`.
2. Di Supabase SQL editor jalankan:
   ```sql
   create table anak (
     id uuid primary key default gen_random_uuid(),
     nama text not null,
     tanggal_lahir date not null,
     vaksin text
   );
   ```
3. Upload folder `backend` dan `frontend` ke GitHub repo.
4. Deploy backend ke Render (pilih root `backend/`). Setelah deploy, ganti `YOUR-BACKEND-URL` di `frontend/src/App.js`.
5. Deploy frontend ke Vercel (pilih root `frontend/`).

## Catatan
- Ganti placeholder `YOUR-PROJECT-URL`, `YOUR-ANON-KEY`, dan `YOUR-BACKEND-URL` sebelum deploy.
- Jangan masukkan keys publik di frontend; frontend di sini memanggil backend yang berkomunikasi dengan Supabase.
- Jika mau integrasikan Google Sheets juga, beri tahu saya apakah Sheets akan jadi sumber data primer (saya bisa bantu sync/ETL).
