import express from "express";
import cors from "cors";
import { createClient } from "@supabase/supabase-js";

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// GANTI dengan URL & ANON KEY dari Supabase project kamu
const supabase = createClient(
  "https://YOUR-PROJECT-URL.supabase.co",
  "YOUR-ANON-KEY"
);

// Route: ambil semua anak
app.get("/api/anak", async (req, res) => {
  const { data, error } = await supabase.from("anak").select("*");
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// Route: tambah anak
app.post("/api/anak", async (req, res) => {
  const { nama, tanggal_lahir, vaksin } = req.body;
  const { data, error } = await supabase.from("anak").insert([{ nama, tanggal_lahir, vaksin }]);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});
