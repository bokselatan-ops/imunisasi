import { useEffect, useState } from "react";

function App() {
  const [anak, setAnak] = useState([]);
  const [form, setForm] = useState({ nama: "", tanggal_lahir: "", vaksin: "" });

  useEffect(() => {
    fetch("https://YOUR-BACKEND-URL.onrender.com/api/anak")
      .then((res) => res.json())
      .then((data) => setAnak(data));
  }, []);

  const tambahAnak = async () => {
    await fetch("https://YOUR-BACKEND-URL.onrender.com/api/anak", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    window.location.reload();
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>📋 Data Anak Imunisasi</h1>

      <div style={{ marginBottom: 20 }}>
        <input placeholder="Nama" onChange={e => setForm({ ...form, nama: e.target.value })} />
        <input type="date" onChange={e => setForm({ ...form, tanggal_lahir: e.target.value })} />
        <input placeholder="Jenis Vaksin" onChange={e => setForm({ ...form, vaksin: e.target.value })} />
        <button onClick={tambahAnak}>Tambah</button>
      </div>

      <ul>
        {anak.map(a => (
          <li key={a.id}>{a.nama} - {a.tanggal_lahir} - {a.vaksin}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
